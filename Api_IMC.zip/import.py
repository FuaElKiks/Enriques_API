pip install flask flask_sqlalchemy werkzeug flask-jwt-extended
